import { createClient } from '@/utils/supabase/server'
// import Error from 'next/error'
import { redirect } from 'next/navigation'

export async function GET(request) {
  const { searchParams } = new URL(request.url)
  console.log(searchParams.get('token_hash'))
  console.log(searchParams.get('type'))
  const token_hash = searchParams.get('token_hash')
  const type = searchParams.get('type') ||  null
  const next = searchParams.get('next') ?? '/'

  if (token_hash && type) {
    if(type === 'signup') {
        console.log(2)
        const supabase = await createClient()
        console.log('Verifying OTP')
        const { error } = await supabase.auth.verifyOtp({
          type,
          token_hash,
        })
        if (!error) {
          redirect(next)
        }
    else if(type === 'password_reset') {
        console.log(3)
        const supabase = await createClient()
        console.log('Verifying OTP')
        const { error } = await supabase.auth.updateUser({
          password : 'password',
        })
        if (!error) {
          redirect(next)
        }
    }
  }
        console.log('Error verifying OTP')

        redirect('/error')
    }
}