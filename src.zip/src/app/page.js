
import Image from "next/image";
import {logout} from "@/app/logout/actions";

export default function Home() {
  return (
    <>
      <form action={logout}>
        {/* <a href="/reset">Reset password</a> */}
        <a href="/private">Private</a>
        <button type="submit">Log out</button>
      </form>
    </>
  );
}
