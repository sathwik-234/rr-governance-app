'use client'

export default function ErrorPage() {
  return <p>Sorry, something went wrong</p>
}